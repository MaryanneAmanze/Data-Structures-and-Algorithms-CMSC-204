// @author Maryanne Amanze 
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface {
    private int tableSize;
    private LinkedList<CourseDBElement>[] hashTable;

    public CourseDBStructure(int estimatedNumCourses) {
        tableSize = loadFunction(estimatedNumCourses, 1.5);
      
        hashTable = new LinkedList[tableSize];
    }

    public CourseDBStructure(String testing, int size) {
        tableSize = size;
        hashTable = new LinkedList[size];
    }

    @Override
    public int getTableSize() {
        return tableSize;
    }

    @Override
    public void add(CourseDBElement element) {
        int hashCode = getHashCode(element.getCRN());
        int index = hashCode % tableSize;

        if (hashTable[index] == null) {
            hashTable[index] = new LinkedList<>();
        }

        // Check if an element with the same CRN already exists
        boolean found = false;
        for (CourseDBElement e : hashTable[index]) {
            if (e.getCRN() == element.getCRN()) {
                e.setID(element.getID()); 
                e.setCredits(element.getCredits());
                e.setRoomNumber(element.getRoomNum());
                e.setInstructorName(element.getInstructorName());
                found = true;
                break;
            }
        }

        if (!found) {
            hashTable[index].add(element);
        }
    }

    @Override
    public CourseDBElement get(int crn) throws IOException {
        int hashCode = getHashCode(crn);
        int index = hashCode % tableSize;

        if (hashTable[index] != null) {
            for (CourseDBElement element : hashTable[index]) {
                if (element.getCRN() == crn) {
                    return element;
                }
            }
        }

        throw new IOException();
    }

    @Override
    public ArrayList<String> showAll() {
       ArrayList<String> list = new ArrayList<>();
		
		for (int i = 0; i < hashTable.length ;i++) {
			if (hashTable[i] != null) {
				for (int j = 0; j < hashTable[i].size(); j++) {
					list.add(hashTable[i].get(j).toString());
				}
			}
		}
		
		return list;
	}



    private int getHashCode(int crn) {
        String crnString = String.valueOf(crn);
        return crnString.hashCode();
    }

    private int getNextPrime(int n) {
        while (true) {
            n++;
            if (isPrime(n)) {
                return n;
            }
        }
    }

    private boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        if (n <= 3) {
            return true;
        }
        if (n % 2 == 0 || n % 3 == 0) {
            return false;
        }
        for (int i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) {
                return false;
            }
        }
        return true;
    }

    private int loadFunction(int n, double load) {
        boolean fkp3 = false;
        boolean isPrime = false;
        int num, highDivisor, deci;

        num = (int) (n / load);

        if (num % 2 == 0) {
            num += 1;
        }

        while (!fkp3) {
            while (!isPrime) {
                highDivisor = (int) (Math.sqrt(num) + 0.5);
                for (deci = highDivisor; deci > 1; deci--) {
                    if (num % deci == 0) {
                        break;
                    }
                }
                if (deci != 1) {
                    num += 2;
                } else {
                    isPrime = true;
                }
            }

            if ((num - 3) % 4 == 0)
                fkp3 = true;
            else {
                num += 2;
                isPrime = false;
            }
        }

        return num;
    }
}
