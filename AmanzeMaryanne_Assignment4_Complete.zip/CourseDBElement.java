
// @author Maryanne Amanze 
public class CourseDBElement implements Comparable<Object>
{

	
	private String courseID;
    private int crn;
    private int credits;
    private String roomNumber;
    private String instructorName;

    public CourseDBElement(String courseID, int crn, int credits, String roomNumber, String instructorName) {
        this.courseID = courseID;
        this.crn = crn;
        this.credits = credits;
        this.roomNumber = roomNumber;
        this.instructorName = instructorName;
    }

    public CourseDBElement() {
		// TODO Auto-generated constructor stub
	}

	public String getID() {
        return courseID;
    }

	public void setID(String courseID) {
		this.courseID = courseID;
	}
	
    public int getCRN() {
        return crn;
    }

    public int getCredits() {
        return credits;
    }
    
    public void setCredits(int numCredits) {
		this.credits = numCredits;
	}
    public String getRoomNum() {
        return roomNumber;
    }
    
    public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

    public String getInstructorName() {
        return instructorName;
    }
    
    public void setInstructorName(String instructor) {
		this.instructorName = instructor;
	}
    
    public int compareTo(CourseDBElement other) {
        // You can implement comparison logic here based on your requirements.
        // For example, you can compare based on CRN or courseID.
        // For simplicity, let's compare based on CRN in ascending order.
        return Integer.compare(this.crn, other.crn);
    }

    @Override
    public String toString() 
    {
    	return "\nCourse:" + courseID + " CRN:" + crn + " Credits:" + credits + " Instructor:" + instructorName + " Room:" + roomNumber;
    }
    
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setCRN(int crn)
	{
		// TODO Auto-generated method stub
		this.crn = crn;
	}

}
