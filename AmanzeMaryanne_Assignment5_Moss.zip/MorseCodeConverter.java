/**
 * MorseCodeConverter class, for converting Morse code to English.
 *
 * @author Maryanne Amanze
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class MorseCodeConverter 
{
    private static MorseCodeTree morseCodeTree = new MorseCodeTree();

    public MorseCodeConverter() {
        // Constructor to initialize the MorseCodeTree
    }

    public static String convertToEnglish(String code) {
    	String[] words = code.split(" / ");
        StringBuilder result = new StringBuilder();

        for (String word : words) {
            String[] letters = word.split(" ");
            for (String letter : letters) {
                result.append(morseCodeTree.fetch(letter));
            }
            result.append(" ");
        }

        return result.toString().trim();
    }

    public static String convertToEnglish(File codeFile) throws FileNotFoundException {
    	Scanner sc = new Scanner(codeFile);
		return convertToEnglish(sc.nextLine());
	}    

    public static String printTree()
    {
		
        	String data = "";
    		ArrayList<String>list = morseCodeTree.toArrayList();
    		for (String s: list) {
    			data+=s+"";
    			System.out.println(s);
    		}
    		
    		return data.trim();
    	    }
    
    }

