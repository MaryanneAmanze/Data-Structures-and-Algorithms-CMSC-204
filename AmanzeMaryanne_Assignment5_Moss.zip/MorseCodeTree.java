/**
 * MorseCodeTree class implements LinkedConverterTreeInterface<String>.
 * It represents a tree structure for Morse code conversion.
 *
 * @author Maryanne Amanze
 */
import java.util.ArrayList;

public class MorseCodeTree implements LinkedConverterTreeInterface<String> {
    private TreeNode<String> root;

    public MorseCodeTree() 
    {
        root = null;
    	buildTree();
    }

    @Override
    public TreeNode<String> getRoot() {
        return root;
    }

    @Override
    public void setRoot(TreeNode<String> newNode) {
        root = new TreeNode<String>(newNode);
    }

    @Override
    public void insert(String code, String letter) {
    	if(root==null){
			root=new TreeNode<String>(letter);
		}
		else {
			addNode(root,code,letter);
		}
    	
	}
    

    @Override
    public String fetch(String code) {
        return fetchNode(root, code);
    }

    @Override
    public MorseCodeTree delete(String data) throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }

    @Override
    public MorseCodeTree update() throws UnsupportedOperationException{
        throw new UnsupportedOperationException();
    }

    @Override
    public void buildTree()
    {
    	insert("","");
		
		insert(".","e"); insert("-","t");
		
		
		insert("..","i"); insert(".-","a");insert("-.","n"); insert("--","m");
		
		
		insert("...","s"); insert("..-","u");insert(".-.","r"); insert(".--","w");insert("-..","d"); insert("-.-","k");insert("--.","g"); insert("---","o");
		
		
		insert("....","h"); insert("...-","v");insert("..-.","f"); insert(".-..","l");insert(".--.","p"); insert(".---","j");insert("-...","b"); insert("-..-","x");insert("-.-.","c"); insert("-.--","y");insert("--..","z"); insert("--.-","q");
		
    }

    @Override
    public ArrayList<String> toArrayList() {
        ArrayList<String> list = new ArrayList<>();
        LNRoutputTraversal(root, list);
        return list;
    }

    public void addNode(TreeNode<String> root, String code, String letter) {
        if (code.length() == 1) {
            if (code.equals(".")) {
                root.setLeft(new TreeNode<>(letter));
            } else if (code.equals("-")) {
                root.setRight(new TreeNode<>(letter));
            }
        } else {
            if (code.charAt(0) == '.') {
                if (root.getLeft() == null) {
                    root.setLeft(new TreeNode<>("")); // Create an empty node if left is null
                }
                addNode(root.getLeft(), code.substring(1), letter);
            } else if (code.charAt(0) == '-') {
                if (root.getRight() == null) {
                    root.setRight(new TreeNode<>("")); // Create an empty node if right is null
                }
                addNode(root.getRight(), code.substring(1), letter);
            }
        }
    }


    @Override
    public String fetchNode(TreeNode<String> root, String code) {
    	String letter="";
		if(code.length()>1) {
			if(code.charAt(0)=='.') {
				letter+=fetchNode(root.left,code.substring(1));
			}
			else {
				letter+=fetchNode(root.right,code.substring(1));
			}
			
		}
		else {
			if(code.equals(".")) {
				letter+=root.left.getData();
				return letter;
			}
			else { 
				letter+=root.right.getData();
				return letter;
			}
		}
		return letter;
	}

    @Override
    public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
    	if(root.left ==null && root.right==null) {
			list.add(root.getData()+" ");
		}
		else {
			if(root.left!=null) {
				LNRoutputTraversal(root.left,list);
				list.add(root.getData()+" ");
			}
			if(root.right!=null) {
				LNRoutputTraversal(root.right,list);
			}
		}
		
    }

}
