import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TownGraphManager implements TownGraphManagerInterface

{
    private Graph townGraph;
	
	public TownGraphManager() {
		townGraph = new Graph();
	}

	@Override
	public boolean addRoad(String town1, String town2, int weight, String roadName) {
		Town theTown1 = getTown(town1);
		Town theTown2 = getTown(town2);
		
		if (theTown1 == null || theTown2 == null)
			
			return false;
		
		if (townGraph.containsEdge(theTown1, theTown2))
			
			return false;
		
		townGraph.addEdge(theTown1, theTown2, weight, roadName);
		
		return true;
	}

	@Override
	public String getRoad(String town1, String town2) 
	{
		String roadGotten = " ";
		Town town1Town = getTown(town1);
		Town town2Town = getTown(town2);
		
		for(Road road : townGraph.edgeSet())
			if (road.contains(town1Town) && road.contains(town2Town))
				roadGotten = road.getName();
		
		return roadGotten;
	}

	public Road getRoadR(String town1, String town2) 
	{
		Road returnedRoad = null;
		Town theTown1 = getTown(town1);
		Town theTown2 = getTown(town2);
		
		for(Road road : townGraph.edgeSet())
			
			if (road.contains(theTown1) && road.contains(theTown2))
				returnedRoad = road;
		
		return returnedRoad;
	}
	
	@Override
	public boolean deleteRoadConnection(String town1, String town2, String road) {
		Road roadReturned = getRoadR(town1, town2);
		townGraph.removeEdge(getTown(town1), getTown(town2), roadReturned.getWeight(), roadReturned.getName());
		return true;
	}
	
	@Override
	public boolean addTown(String v) 
	{
		return townGraph.addVertex(new Town(v));
	}

	@Override
	public Town getTown(String name) 
	{
		Town theTown = null;
		
		for (Town town : townGraph.vertexSet())
			if (town.getName().equals(name))
				theTown = town;
		return theTown;
	}

	@Override
	public boolean containsTown(String v) {
		if (getTown(v) == null)
			return false;
		else
			return true;
	}

	@Override
	public boolean containsRoadConnection(String town1, String town2) {
		return townGraph.containsEdge(getTown(town1), getTown(town2));

	}

	@Override
	public ArrayList<String> allRoads() {
		ArrayList<String> roads = new ArrayList<>();
		for (Road road: townGraph.edgeSet())
			roads.add(road.getName());
		
		roads.sort(String.CASE_INSENSITIVE_ORDER);
		return roads;
	}

	

	@Override
	public boolean deleteTown(String v) 
	{
	boolean var = false;
		
	if(townGraph.removeVertex(new Town(v))) 
	{
		var =true;
	}
		return var;
	}

	@Override
	public ArrayList<String> allTowns() 
	{
		ArrayList<String> towns = new ArrayList<>();
		
		for (Town town : townGraph.vertexSet())
			towns.add(town.getName());
		
		towns.sort(String.CASE_INSENSITIVE_ORDER);
		return towns;
	}

	@Override
	public ArrayList<String> getPath(String town1, String town2) {
		return townGraph.shortestPath(getTown(town1), getTown(town2));

	}

	public void populateTownGraph(File selectedFile) throws FileNotFoundException 
	{
		 //...
		Scanner inFile = new Scanner(selectedFile);

        while (inFile.hasNextLine()) {
            String line = inFile.nextLine();
            String[] parts = line.split(";");

            if (parts.length == 3) {
                String roadName = parts[0].trim();
                int weight = Integer.parseInt(parts[1].trim());
                String sourceTown = parts[2].trim();
                String destinationTown = parts[3].trim();

                addTown(sourceTown);
                addTown(destinationTown);

                addRoad(sourceTown, destinationTown, weight, roadName);
            }
        }

        inFile.close();
    }
	
}

	


	

