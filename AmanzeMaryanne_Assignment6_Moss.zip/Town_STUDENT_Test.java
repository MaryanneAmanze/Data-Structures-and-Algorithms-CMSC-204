import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * This class contains JUnit tests for the Town class.
 * It tests each method in the Town class.
 *
 * @author Maryanne Amanze
 * 
 */
class Town_STUDENT_Test 
{

	private Town town1;
    private Town town2;
    private Town town3;

    @BeforeEach
    public void setUp() throws Exception {
        town1 = new Town("Town1");
        town2 = new Town("Town2");
        town3 = new Town(town1); 
    }

    @AfterEach
    public void tearDown() throws Exception {
        town1 = null;
        town2 = null;
        town3 = null;
    }

    @Test
    public void testConstructorWithName() {
        assertEquals("Town1", town1.getName());
        assertEquals("Town2", town2.getName());
        assertEquals("Town1", town3.getName()); 
    }

    @Test
    public void testEquals() {
        assertTrue(town1.equals(town3)); 
        assertFalse(town1.equals(town2)); 
    }

    @Test
    public void testGetName() {
        assertEquals("Town1", town1.getName());
        assertEquals("Town2", town2.getName());
    }

    @Test
    public void testHashCode() {
        assertEquals(town1.hashCode(), town3.hashCode()); 
        assertNotEquals(town1.hashCode(), town2.hashCode()); 
    }

    @Test
    public void testToString() {
        assertEquals("Town{name='Town1'}", town1.toString());
    }

    @Test
    public void testCompareTo() {
        assertTrue(town1.compareTo(town2) < 0); 
        assertTrue(town2.compareTo(town1) > 0); 
        assertEquals(0, town1.compareTo(town3)); 
    }

}
