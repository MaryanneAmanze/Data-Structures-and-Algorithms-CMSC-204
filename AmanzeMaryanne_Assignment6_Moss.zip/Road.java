
public class Road implements Comparable<Road>
{

	private Town source;
	private Town destination;
	private String name;
	private int weight;
	
	public Road(Town source, Town destination, int weight, String name)
	{
		this.source = source;
		this.destination = destination;
		this.weight = weight;
		this.name = name;
	}
	
	public Road(Town source, Town destination, String name)
	{
		 this(source, destination, 1, name);
	}
	
	public String toString() {
        return "Road{" +
                "connecting " + source.getName() +
                " to " + destination.getName() +
                " by " + getWeight() + " miles" +
                ", name='" + getName() + '\'' +
                '}';
    }
	
	public int getWeight()
	{
		return weight;
	}
	
	public Town getSource()
	{
		return source;
	}
	
	public String getName()
	{
		return name;
	}
	
	public Town getDestination()
	{
		return destination;
	}
	
	public boolean equals(Object r) {
	    if (this == r) return true;
	    if (r == null || getClass() != r.getClass()) return false;

	    Road newR = (Road) r;

	    return (newR.destination.equals(destination) && newR.source.equals(source)) ||
	           (newR.destination.equals(source) && newR.source.equals(destination));
	}
	
	
	public boolean contains(Town town)
	{
		if (town == null)
			return false;
		
		if (source.equals(town)) {
			return true;
		} else if (destination.equals(town)) {
			return true;
		}
		
		return false;
	}
	
	
	@Override
	public int compareTo(Road o) 
	{
		return weight - o.getWeight();
		
	}
	
	

}
