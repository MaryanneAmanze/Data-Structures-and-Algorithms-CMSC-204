import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * This class contains JUnit tests for the TownGraphManager class.
 * It tests each method in the TownGraphManager class.
 *
 * @author Maryanne Amanze
 * 
 */
class TownGraphManager_STUDENT_Test {

	 private TownGraphManagerInterface graph;
	    private String[] town;

	    @BeforeEach
	    public void setUp() throws Exception {
	        graph = new TownGraphManager();
	        town = new String[15];

	        for (int i = 1; i < 15; i++) {
	            town[i] = "City_" + i;
	            graph.addTown(town[i]);
	        }

	        graph.addRoad(town[1], town[2], 3, "Street_1");
	        graph.addRoad(town[1], town[3], 5, "Street_2");
	        graph.addRoad(town[1], town[5], 7, "Street_3");
	        graph.addRoad(town[2], town[4], 2, "Street_4");
	        graph.addRoad(town[3], town[6], 4, "Street_5");
	        graph.addRoad(town[4], town[7], 1, "Street_6");
	        graph.addRoad(town[5], town[8], 6, "Street_7");
	        graph.addRoad(town[6], town[9], 3, "Street_8");
	        graph.addRoad(town[7], town[10], 2, "Street_9");
	        graph.addRoad(town[8], town[11], 5, "Street_10");
	        graph.addRoad(town[9], town[12], 1, "Street_11");
	        graph.addRoad(town[10], town[13], 4, "Street_12");
	        graph.addRoad(town[11], town[14], 3, "Street_13");
	    }

	    @AfterEach
	    public void tearDown() throws Exception {
	        graph = null;
	    }

	    @Test
	    public void testAddRoad() {
	        ArrayList<String> roads = graph.allRoads();
	        assertEquals("Street_1", roads.get(0));
	        assertEquals("Street_10", roads.get(9));
	        assertEquals("Street_13", roads.get(12));
	        graph.addRoad(town[12], town[14], 2, "Street_14");
	        roads = graph.allRoads();
	        assertEquals("Street_1", roads.get(0));
	        assertEquals("Street_10", roads.get(9));
	        assertEquals("Street_13", roads.get(12));
	        assertEquals("Street_14", roads.get(13));
	    }

	    @Test
	    public void testGetRoad() {
	        assertEquals("Street_8", graph.getRoad(town[6], town[9]));
	        assertEquals("Street_5", graph.getRoad(town[3], town[6]));
	    }

	    @Test
	    public void testAddTown() {
	        assertEquals(false, graph.containsTown("City_16"));
	        graph.addTown("City_16");
	        assertEquals(true, graph.containsTown("City_16"));
	    }

	    @Test
	    public void testDisjointGraph() {
	        assertEquals(false, graph.containsTown("City_16"));
	        graph.addTown("City_16");
	        ArrayList<String> path = graph.getPath(town[1], "City_16");
	        assertFalse(path.size() > 0);
	    }

	    @Test
	    public void testContainsTown() {
	        assertEquals(true, graph.containsTown("City_2"));
	        assertEquals(false, graph.containsTown("City_16"));
	    }

	    @Test
	    public void testContainsRoadConnection() {
	        assertEquals(true, graph.containsRoadConnection(town[3], town[6]));
	        assertEquals(false, graph.containsRoadConnection(town[4], town[9]));
	    }

	    @Test
	    public void testAllRoads() {
	        ArrayList<String> roads = graph.allRoads();
	        assertEquals("Street_1", roads.get(0));
	        assertEquals("Street_10", roads.get(9));
	        assertEquals("Street_13", roads.get(12));
	        assertEquals("Street_4", roads.get(3));
	        assertEquals("Street_11", roads.get(10));
	    }

	    @Test
	    public void testDeleteRoadConnection() {
	        assertEquals(true, graph.containsRoadConnection(town[3], town[6]));
	        graph.deleteRoadConnection(town[3], town[6], "Street_5");
	        assertEquals(false, graph.containsRoadConnection(town[3], town[6]));
	    }

	    @Test
	    public void testDeleteTown() {
	        assertEquals(true, graph.containsTown("City_2"));
	        graph.deleteTown(town[2]);
	        assertEquals(false, graph.containsTown("City_2"));
	    }

	    @Test
	    public void testAllTowns() {
	        ArrayList<String> towns = graph.allTowns();
	        assertEquals("City_1", towns.get(0));
	        assertEquals("City_10", towns.get(9));
	        assertEquals("City_14", towns.get(13));
	        assertEquals("City_6", towns.get(5));
	        assertEquals("City_12", towns.get(11));
	    }

	    @Test
	    public void testGetPath() {
	        ArrayList<String> path = graph.getPath(town[1], town[14]);
	        assertNotNull(path);
	        assertTrue(path.size() > 0);
	        assertEquals("City_1 via Street_3 to City_5 7 mi", path.get(0).trim());
	        assertEquals("City_5 via Street_7 to City_8 6 mi", path.get(1).trim());
	        
	    }
}
