import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * This class contains JUnit tests for the Graph class.
 * It tests each method in the Graph class.
 *
 * @author Maryanne Amanze
 * 
 */
class Graph_STUDENT_Test 
{

	private GraphInterface<Town, Road> graph;
    private Town[] towns;

    @BeforeEach
    public void setUp() throws Exception {
        graph = new Graph();
        towns = new Town[5];

        for (int i = 0; i < 5; i++) {
            towns[i] = new Town("StudentTown_" + i);
            graph.addVertex(towns[i]);
        }

        graph.addEdge(towns[0], towns[1], 2, "StudentRoad_1");
        graph.addEdge(towns[0], towns[2], 4, "StudentRoad_2");
        graph.addEdge(towns[1], towns[3], 3, "StudentRoad_3");
        graph.addEdge(towns[2], towns[4], 1, "StudentRoad_4");
    }

    @AfterEach 
    public void tearDown() throws Exception {
        graph = null;
    }

    @Test
    public void testGetEdge() {
        Road edge = graph.getEdge(towns[0], towns[1]);
        assertNotNull(edge);
        assertEquals(2, edge.getWeight());
        assertEquals("StudentRoad_1", edge.getName());

        assertNull(graph.getEdge(towns[1], towns[4])); 
    }

    @Test
    public void testAddEdge() {
        assertFalse(graph.containsEdge(towns[1], towns[4]));

        Road newEdge = graph.addEdge(towns[1], towns[4], 5, "StudentRoad_5");
        assertTrue(graph.containsEdge(towns[1], towns[4]));
        assertEquals(newEdge, graph.getEdge(towns[1], towns[4]));
    }

    @Test
    public void testAddVertex() {
        Town newTown = new Town("StudentTown_5");
        assertFalse(graph.containsVertex(newTown));

        assertTrue(graph.addVertex(newTown));
        assertTrue(graph.containsVertex(newTown));
    }

    @Test
    public void testContainsEdge() {
        assertTrue(graph.containsEdge(towns[2], towns[4]));
        assertFalse(graph.containsEdge(towns[3], towns[0]));
    }

    @Test
    public void testContainsVertex() {
        assertTrue(graph.containsVertex(new Town("StudentTown_3")));
        assertFalse(graph.containsVertex(new Town("NonExistingTown")));
    }

    @Test
    public void testEdgeSet() {
        Set<Road> edges = graph.edgeSet();
        assertEquals(4, edges.size());
        assertTrue(edges.contains(graph.getEdge(towns[0], towns[1])));
        assertTrue(edges.contains(graph.getEdge(towns[0], towns[2])));
    }

    @Test
    public void testEdgesOf() {
        Set<Road> edges = graph.edgesOf(towns[0]);
        assertEquals(2, edges.size());
        assertTrue(edges.contains(graph.getEdge(towns[0], towns[1])));
        assertTrue(edges.contains(graph.getEdge(towns[0], towns[2])));
    }

}
