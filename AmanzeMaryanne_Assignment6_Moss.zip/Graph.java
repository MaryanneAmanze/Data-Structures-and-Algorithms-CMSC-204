
import java.util.*;

public class Graph implements GraphInterface<Town, Road> 
{

	private Set<Road> roads;
	private Set<Town> towns;
	private Set<Town> unvisited;
	private Set<Town> visited;
	private Map<Town, Integer> distance;
	private Map<Town, List<Road>> adjacencyList;
	private Map<Town, Town> previousVertex = new HashMap<>();

	public Graph()
	{
		this.roads = new HashSet<>();
        this.towns = new HashSet<>();
        this.unvisited = new HashSet<>();
        this.visited = new HashSet<>();
        this.distance = new HashMap<>();
        this.adjacencyList = new HashMap<>();
	}

	@Override
	public Road getEdge(Town sourceVertex, Town destinationVertex) {
		for (Road road : roads)
			if (road.contains(sourceVertex) && road.contains(destinationVertex))
				return road;
		
		return null;
	}

	@Override
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		Road newRoad = new Road(sourceVertex, destinationVertex, weight, description);
        roads.add(newRoad);

        adjacencyList.computeIfAbsent(sourceVertex, k -> new ArrayList<>()).add(newRoad);
        adjacencyList.computeIfAbsent(destinationVertex, k -> new ArrayList<>()).add(newRoad);

        return newRoad;
    }
	

	@Override
	public boolean addVertex(Town v) {
		return towns.add(v);
	}

	@Override
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
        return getEdge(sourceVertex, destinationVertex) != null;

	}

	@Override
	public boolean containsVertex(Town v) {
		return towns.contains(v);
	}

	@Override
	public Set<Road> edgeSet() {
		return roads;
	}

	@Override
	public Set<Road> edgesOf(Town vertex) {
		 return new HashSet<>(adjacencyList.get(vertex));
	}

	@Override
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		Road roadRemoved = null;
		for(Road road : roads) {
			if (road.contains(sourceVertex) && road.contains(destinationVertex))
				if (road.getWeight() == weight && road.getName().equals(description)) {
					roadRemoved = road;
					roads.remove(road);
					break;
				}
		}
		
		return roadRemoved;
	}

	@Override
	public boolean removeVertex(Town v) {
		if (!towns.contains(v)) {
            return false;
        }
 
		towns.remove(v);
        unvisited.remove(v);
        visited.remove(v);
        distance.remove(v);

        List<Road> roadsToRemove = adjacencyList.remove(v);
        if (roadsToRemove != null) {
            roads.removeAll(roadsToRemove);
            for (Road road : roadsToRemove) {
                Town otherTown = (road.getSource().equals(v)) ? road.getDestination() : road.getSource();
                adjacencyList.get(otherTown).remove(road);
                
            }
        }
            return true;
	}

	@Override
	public Set<Town> vertexSet() {
		return towns;
	}

	@Override
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		dijkstraShortestPath(sourceVertex);

	    ArrayList<String> path = new ArrayList<>();
	    Town current = destinationVertex;

	    while (current != null) {
	        path.add(current.getName());
	        current = previousVertex.get(current);
	    }

	    Collections.reverse(path);
	    return path;
	}

	@Override
	public void dijkstraShortestPath(Town sourceVertex) {
		distance.clear();
        unvisited.addAll(towns);

        distance.put(sourceVertex, 0);

        while (!unvisited.isEmpty()) {
            Town current = getMinDistanceTown();
            unvisited.remove(current);

            for (Road road : adjacencyList.getOrDefault(current, Collections.emptyList())) {
                Town neighbor = getNeighbor(current, road);
                if (unvisited.contains(neighbor)) {
                    int newDistance = distance.get(current) + road.getWeight();
                    if (newDistance < distance.getOrDefault(neighbor, Integer.MAX_VALUE)) {
                        distance.put(neighbor, newDistance);
                    }
                }
            }
        }
    }

    private Town getMinDistanceTown() {
        Town minTown = null;
        int minDistance = Integer.MAX_VALUE;

        for (Town town : unvisited) {
            int dist = distance.getOrDefault(town, Integer.MAX_VALUE);
            if (dist < minDistance) {
                minDistance = dist;
                minTown = town;
            }
        }

        return minTown;
    }

    private Town getNeighbor(Town current, Road road) {
        return road.getSource().equals(current) ? road.getDestination() : road.getSource();
    }
	
}	