import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
/**
 * This class contains JUnit tests for the Road class.
 * It tests each method in the Road class.
 *
 * @author Maryanne Amanze
 * 
 */
class Road_STUDENT_Test {

	 private Town town1;
	    private Town town2;
	    private Road road1;
	    private Road road2;

	    @BeforeEach
	    public void setUp() throws Exception {
	        town1 = new Town("Town1");
	        town2 = new Town("Town2");
	        road1 = new Road(town1, town2, 3, "Road1");
	        road2 = new Road(town2, town1, 2, "Road2");
	    }

	    @AfterEach
	    public void tearDown() throws Exception {
	        town1 = null;
	        town2 = null;
	        road1 = null;
	        road2 = null;
	    }

	    @Test
	    public void testConstructorWithWeight() {
	        assertEquals(town1, road1.getSource());
	        assertEquals(town2, road1.getDestination());
	        assertEquals(3, road1.getWeight());
	        assertEquals("Road1", road1.getName());
	    }

	    @Test
	    public void testConstructorWithoutWeight() {
	        assertEquals(town2, road2.getSource());
	        assertEquals(town1, road2.getDestination());
	        assertEquals("Road2", road2.getName());
	    }

	    @Test
	    public void testToString() {
	        assertEquals("Road{connecting Town1 to Town2 by 3 miles, name='Road1'}", road1.toString());
	    }

	    @Test
	    public void testGetWeight() {
	        assertEquals(3, road1.getWeight());
	    }

	    @Test
	    public void testGetSource() {
	        assertEquals(town1, road1.getSource());
	        assertEquals(town2, road2.getSource());
	    }

	    @Test
	    public void testGetName() {
	        assertEquals("Road1", road1.getName());
	        assertEquals("Road2", road2.getName());
	    }

	    @Test
	    public void testGetDestination() {
	        assertEquals(town2, road1.getDestination());
	        assertEquals(town1, road2.getDestination());
	    }

	    @Test
	    public void testEquals() {
	        assertTrue(road1.equals(new Road(town1, town2, 3, "Road1")));
	        assertTrue(road1.equals(new Road(town2, town1, 3, "Road1")));

	    }

	    @Test
	    public void testContains() {
	        assertTrue(road1.contains(town1));
	        assertTrue(road1.contains(town2));
	        assertFalse(road1.contains(new Town("DifferentTown")));
	    }

	    @Test
	    public void testCompareTo() {
	        assertTrue(road1.compareTo(new Road(town2, town1, 2, "Road2")) > 0);
	        assertTrue(road1.compareTo(new Road(town2, town1, 4, "Road3")) < 0);
	        assertTrue(road1.compareTo(new Road(town2, town1, 3, "Road4")) == 0);
	    }
}
