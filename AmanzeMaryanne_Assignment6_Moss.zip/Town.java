import java.util.Objects;

public class Town implements Comparable<Town>
{

	
	private String name;
	
	public Town(String name)
	{
		this.name = name;
	}
	
	public Town(Town testTown) {
		name = testTown.getName();
	}
	
	public boolean equals(Object r) 
	{
		return ((Town) r).getName().equals(name);
	}
	
	public String getName()
	{
		return name;
	}
	
	public int hashCode()
	{
		return name.hashCode();
	}
	
	public String toString()
	{
		return "Town{" +
                "name='" + name + '\'' +
                '}';
	}
	
	@Override
	public int compareTo(Town o) {
		return name.compareTo(o.getName());

	}

}
