// @author Maryanne Amanze 
import java.io.IOException;
import javafx.scene.control.Alert;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {
    private CourseDBStructure cds;

    public CourseDBManager() {
        cds = new CourseDBStructure(100); // Initialize the CourseDBStructure
    }

  
	@Override
    public void add(String id, int crn, int credits, String room, String instructor) {
		cds.add(new CourseDBElement(id, crn, credits, room, instructor));
    }

    @Override
    public CourseDBElement get(int crn) {
        try
        {
    	return cds.get(crn);
        }
    	catch(IOException e)
    	{
    		System.out.println(e.getMessage());
    	}
    	return null;
    }

    public void readFile(File input) throws FileNotFoundException {
		if (input != null) {
			Scanner fileReader = null;
			try {
				fileReader = new Scanner(input);
				while(fileReader.hasNext()) {
					String[] line = fileReader.nextLine().split(" ");
					add(line[0], Integer.parseInt(line[1]), Integer.parseInt(line[2]), line[3], line[4]);
				}
			} catch (FileNotFoundException e) {
				throw e;
			} finally {
				if (fileReader != null) {
					fileReader.close();
				}
			}
		} else {
			throw new FileNotFoundException();
		}
		
	}
    
    @Override
    public String toString() {
        return cds.toString();
    }

     


	@Override
	public ArrayList<String> showAll() {
		return cds.showAll();
	}
	
}
