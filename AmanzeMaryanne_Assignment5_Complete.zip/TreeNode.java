/**
	 * TreeNode class
	 *
	 * @param <T> type parameter
	 *  @author Maryanne Amanze
	 */
public class TreeNode <T>
{
	
	    private T data;
	    protected TreeNode<T> left;
	    protected TreeNode<T> right;

	    /**
	     * creates a new tree node with left and right child set to null and data set to dataNode
	     *
	     * @param dataNode data to be stored in the tree node
	     */
	    public TreeNode(T dataNode) {
	        data = dataNode;
	        left = null;
	        right = null;
	    }

	    /**
	     * used to make deep copies
	     *
	     * @param node to be copied
	     */
	    public TreeNode(TreeNode<T> node) {
	        this(node.getLeft(), node.getRight(), node.getData());
	    }

	    /**
	     * creates a new node with the supplied information
	     *
	     * @param left  left child
	     * @param right right child
	     * @param info  data stores in the node
	     */
	    public TreeNode(TreeNode<T> left, TreeNode<T> right, T info) {
	        data = info;
	        left = new TreeNode<>(left);
	        right = new TreeNode<>(right);
	    }

	    /**
	     * returns data stored in a tree node
	     *
	     * @return data
	     */
	    public T getData() {
	        return data;
	    }

	    /**
	     * Get the left child of the tree node
	     *
	     * @return left child
	     */
	    public TreeNode<T> getLeft() {
	        return left;
	    }

	    /**
	     * Set the left child of the tree node
	     *
	     * @param leftChild left child
	     */
	    public void setLeft(TreeNode<T> left) {
	        this.left = left;
	    }

	    /**
	     * Get the right child of the tree node
	     *
	     * @return right child
	     */
	    public TreeNode<T> getRight() {
	        return right;
	    }

	    /**
	     * Set the right child of the tree node
	     *
	     * @param rightChild right child
	     */
	    public void setRight(TreeNode<T> right) {
	        this.right = right;
	    }
	}

	

	
	

