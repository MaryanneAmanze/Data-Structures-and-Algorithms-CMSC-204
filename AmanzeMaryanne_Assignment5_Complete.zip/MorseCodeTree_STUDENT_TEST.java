/**
 *  JUnit test class for testing MorseCodeTree.
 * 
 *
 * @author Maryanne Amanze
 */
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MorseCodeTree_STUDENT_TEST 
{

	MorseCodeTree tree = new MorseCodeTree();
	ArrayList<String> treeList = new ArrayList<>();

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	public void testFetch() {	
		String str = tree.fetch(".---");
		assertEquals("j",str);
	}
	
}
