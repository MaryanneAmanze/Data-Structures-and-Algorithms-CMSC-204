/**
 * JUnit test class for testing MorseCodeConverter.
 * 
 *
 * @author Maryanne Amanze
 */
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MorseCodeConverter_STUDENT_TEST {

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	 public void testConvertToEnglishString() {
        // Test for convertToEnglish(String)
        String morseCode = ".... --- .-.. .-.. --- / .-- --- .-. .-.. -..";
        String expected = "hollo world";
        assertEquals(expected, MorseCodeConverter.convertToEnglish(morseCode));
    }
	
	public void testConvertToEnglishFile() {
		File file = new File("src/howDoILoveThee.txt");
        try {
            String expected = "how do i love thee let me count the ways";
            assertEquals(expected, MorseCodeConverter.convertToEnglish(file));
        } catch (FileNotFoundException e) {
            fail("An unwanted exception was caught: " + e.getMessage());
        }
    }
}
